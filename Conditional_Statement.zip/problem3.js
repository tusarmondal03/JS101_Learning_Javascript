
let bill=4000;

const min=3999;

if(bill>=min)
{
  console.log(bill*0.9);
}
else
{
  
}
  