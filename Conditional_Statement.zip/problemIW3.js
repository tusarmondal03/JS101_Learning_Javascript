var a = 34;
var b = 23;

if(a>b)
{
  console.log(a + " is greater than " + b);
}
else if(a<b)
{
  console.log(b + " is greater than " + a);
}else
{
  console.log("both equal");
}