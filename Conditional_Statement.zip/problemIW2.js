let age = 20;

const min_age = 18;

if(age>=min_age)
{
  console.log("Apply for a license");
}
else
{
  console.log("NA");
}