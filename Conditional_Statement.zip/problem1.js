let a = 10;
let b = 10;

if (a == b) {
  console.log("Both are equal");
}