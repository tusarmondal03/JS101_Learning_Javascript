const price = 4000;
const min = 3999;

if(price >= min)
{
  console.log("Got discount");
}
else{
  console.log("Not eligible");
}