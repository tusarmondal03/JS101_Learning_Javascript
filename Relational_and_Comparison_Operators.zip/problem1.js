// Rahul went to Big Bazar, he purchased items worth 4000, then he saw that there is a deal, If you

 price = 3000;

if(price > 4999)
{
  console.log("Eligible for discount");
}
else{
  console.log("No Discount(false)");
}